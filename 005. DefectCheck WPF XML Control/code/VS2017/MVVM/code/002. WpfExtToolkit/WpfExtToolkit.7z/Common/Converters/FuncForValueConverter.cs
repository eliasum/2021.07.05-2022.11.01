﻿using System;
using System.Globalization;
using System.Reflection;
using System.Windows;
using System.Windows.Data;
using System.Windows.Markup;

namespace Converters
{
    public class FuncForValueConverter : IValueConverter
    {
        public static FuncForValueConverter Instance { get; } = new FuncForValueConverter();

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (parameter is Delegate func)
            {
                MethodInfo method = func.Method;

                Type retType = method.ReturnType;
                if (retType != null && retType != typeof(void))
                {
                    ParameterInfo[] parameters = method.GetParameters();
                    if (parameters.Length == 1)
                    {
                        try
                        {
                            return func.DynamicInvoke(new object[] { value });
                        }
                        catch (Exception)
                        { }
                    }
                }
            }

            return DependencyProperty.UnsetValue;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }


    }
    public class FuncForValueConverterExtension : MarkupExtension
    {
        public override object ProvideValue(IServiceProvider serviceProvider)
            => FuncForValueConverter.Instance;
    }
}
