﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Markup;
using System.Windows.Media;

namespace Converters
{
    public class GetElementFromItemsControlContainerConverter : IMultiValueConverter
    {
        #region IValueConverter Members

        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (values == null
                || values.Length < 2
                || !(values[0] is ItemsControl itemsControl)
                || values[1] is null)
                return DependencyProperty.UnsetValue;

            var item = itemsControl.ItemContainerGenerator.ContainerFromItem(values[1]);

            if (item == null)
                return DependencyProperty.UnsetValue;
            return VisualTreeHelper.GetChild(item, 0);
        }

        object[] IMultiValueConverter.ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        #endregion

        public static GetElementFromItemsControlContainerConverter Instance { get; }
            = new GetElementFromItemsControlContainerConverter();
    }

    public class GetElementFromItemsControlContainerConverterExtension : MarkupExtension
    {
        public override object ProvideValue(IServiceProvider serviceProvider)
        {
            return GetElementFromItemsControlContainerConverter.Instance;
        }
    }
}
