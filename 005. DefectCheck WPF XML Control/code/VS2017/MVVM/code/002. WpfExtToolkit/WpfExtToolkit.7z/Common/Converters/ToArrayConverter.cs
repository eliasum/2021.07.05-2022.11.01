﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Markup;

namespace Converters
{
    [ValueConversion(typeof(object), typeof(object[]))]
    public class ToArrayConverter : IValueConverter, IMultiValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
            => new object[] { value };

        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            return values?.Clone();
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        public static ToArrayConverter Instance { get; } = new ToArrayConverter();
    }

    public class ToArrayConverterExtension : MarkupExtension
    {
        public override object ProvideValue(IServiceProvider serviceProvider)
            => ToArrayConverter.Instance;
    }
}
