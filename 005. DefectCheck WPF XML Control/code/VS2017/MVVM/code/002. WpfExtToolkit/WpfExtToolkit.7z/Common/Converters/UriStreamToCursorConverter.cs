﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Resources;

namespace Converters
{
    public class UriStreamToCursorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            try
            {
                if (value is Cursor cursor)
                    return cursor;
                if (!(value is Uri uri))
                {
                    uri = new Uri(value.ToString(), UriKind.Relative);
                }
                if (!cursors.TryGetValue(uri, out cursor))
                {

                    StreamResourceInfo sri = Application.GetResourceStream(uri);
                    cursors.Add(uri, cursor = new Cursor(sri.Stream));
                }
                return cursor;
            }
            catch (Exception)
            {
                return value;
            }
        }

        private static readonly Dictionary<Uri, Cursor> cursors = new Dictionary<Uri, Cursor>();

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        public static UriStreamToCursorConverter Instance { get; } = new UriStreamToCursorConverter();
    }
    public class UriStreamToCursorConverterExtension : MarkupExtension
    {
        public override object ProvideValue(IServiceProvider serviceProvider)
        {
            return UriStreamToCursorConverter.Instance;
        }
    }
}
