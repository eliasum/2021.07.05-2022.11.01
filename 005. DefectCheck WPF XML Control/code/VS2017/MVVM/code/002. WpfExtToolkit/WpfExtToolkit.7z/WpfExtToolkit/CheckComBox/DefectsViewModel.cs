﻿using Simplified;
using System.Collections.ObjectModel;
using System.Xml.Linq;

namespace WpfExtToolkit.CheckComBox
{
    public class DefectsViewModel : BaseInpc
    {

        public ObservableCollection<DefectTypeDto> Defects { get; }
            = new ObservableCollection<DefectTypeDto>();
        public ObservableCollection<DefectTypeDto> SelectedDefects { get; }
            = new ObservableCollection<DefectTypeDto>();

        private string _selectedValueDefects;
        public string SelectedValueDefects { get => _selectedValueDefects; set => Set(ref _selectedValueDefects, value); }

        public DefectsViewModel()
        {
            XElement defectTypes = XElement.Parse(
@"<Type title='Тип' description='Тип дефекта'>
	<Item key='01' title='Настройка00'/>
	<Item key='02' title='Настройка01'/>
	<Item key='03' title='Настройка02'/>
	<Item key='04' title='Настройка03'/>
	<Item key='05' title='Настройка04'/>
	<Item key='06' title='Настройка05'/>
	<Item key='07' title='Настройка06'/>
	<Item key='08' title='Настройка07'/>
	<Item key='09' title='Настройка08'/>
	<Item key='10' title='Настройка09'/>
</Type>");

            foreach (XElement item in defectTypes.Elements("Item"))
            {
                DefectTypeDto defect = new DefectTypeDto
                {
                    Id = int.Parse(item.Attribute("key").Value),
                    Title = item.Attribute("title").Value
                };
                Defects.Add(defect);
            }
        }

        private RelayCommand _inputValuesCommand;
        public RelayCommand InputValuesCommand => _inputValuesCommand
            ?? (_inputValuesCommand = new RelayCommand<string>(values => SelectedValueDefects = values));
    }
}
