﻿using Common;
using Simplified;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

namespace WpfExtToolkit.CheckComBox
{
    public class ProductDefectsViewModel : BaseInpc
    {

        public ObservableCollection<DefectTypeXml> DefectsTypes { get; }
            = new ObservableCollection<DefectTypeXml>();
        public ObservableCollection<SlotXml> Slots { get; }
            = new ObservableCollection<SlotXml>();

        private string _selectedValueDefects;
        public string SelectedValueDefects { get => _selectedValueDefects; set => Set(ref _selectedValueDefects, value); }

        private static readonly XmlSerializer productSerializer = new XmlSerializer(typeof(ProductXml));
        private readonly ProductXml product;
        private const string fileName = "CheckComBox/product.xml";
        public ProductDefectsViewModel()
        {
            using (FileStream file = File.OpenRead(fileName))
            {
                product = (ProductXml)productSerializer.Deserialize(file);
            }

            DefectsTypes.AddRange(product.DefectTypes.Types);
            Slots.AddRange(product.Slots);
        }

        private RelayCommand _saveCommand;
        public RelayCommand SaveCommand => _saveCommand
            ?? (_saveCommand = new RelayCommand(SaveExecute));
        private void SaveExecute()
        {
            product.DefectTypes.Types = DefectsTypes.ToList();
            product.Slots = Slots.ToList();

            using (FileStream file=File.Create(fileName))
            {
                productSerializer.Serialize(file, product);
            }
        }
    }
}
