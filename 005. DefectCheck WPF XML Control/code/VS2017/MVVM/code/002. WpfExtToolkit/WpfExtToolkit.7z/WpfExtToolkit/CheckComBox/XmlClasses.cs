﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Xml.Serialization;

namespace WpfExtToolkit.CheckComBox
{

    [Serializable()]
    [DesignerCategory("code")]
    [XmlType(AnonymousType = true)]
    [XmlRoot(Namespace = "", IsNullable = false, ElementName = "Product")]
    public partial class ProductXml
    {
        public DefectTypesXml DefectTypes { get; set; }

        [XmlArrayItem("Slot", IsNullable = false)]
        public List<SlotXml> Slots { get; set; }

        /// <remarks/>
        [XmlAttribute("title")]
        public string Title { get; set; }
    }

    /// <remarks/>
    [Serializable()]
    [DesignerCategory("code")]
    [XmlType(AnonymousType = true)]
    public partial class DefectTypesXml 
    {
        [XmlElement("DefectType")]
        public List<DefectTypeXml> Types { get; set; }

        [XmlAttribute("title")]
        public string Title { get; set; }

        [XmlAttribute("description")]
        public string Description { get; set; }
    }

    /// <remarks/>
    [Serializable()]
    [DesignerCategory("code")]
    [XmlType(AnonymousType = true)]
    public partial class DefectTypeXml
    {
        [XmlAttribute("key")]
        public int Key { get; set; }

        [XmlAttribute("title")]
        public string Title { get; set; }

        public override string ToString() => Title;
    }

    [Serializable()]
    [DesignerCategory("code")]
    [XmlType(AnonymousType = true)]
    public partial class SlotXml
    {
        [XmlAttribute("key")]
        public int Key { get; set; }

        [XmlAttribute("defects")]
        public string Defects { get; set; }
    }
}
