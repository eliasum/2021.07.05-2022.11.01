﻿namespace _MTF.Viewer.Control
{
    using System;
    using System.Xml;
    using System.Windows;
    using System.Threading;
    using System.Reflection;
    using System.Globalization;
    using System.Collections.ObjectModel;
    using System.Windows.Controls;
    using System.Windows.Media;

    public partial class CustomChart : UserControl
    {
        private ReaderWriterLockSlim occupied;
        private ObservableCollection<Point> collection;

        public CustomChart() { InitializeComponent(); }
    }
}
